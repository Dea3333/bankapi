from rest_framework import serializers
from django.contrib.auth.models import User
from decimal import Decimal
from .models import BankAccount, Transaction



class UserSerializer(serializers.ModelSerializer):
    password = serializers.CharField(
        write_only=True,
        min_length=8,
        style={'input_type': 'password'}
    )

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'password']
        read_only_fields = ['id']

    def validate_username(self, value):
        if User.objects.filter(username=value).exists():
            raise serializers.ValidationError("Username already exists.")
        return value

    def create(self, validated_data):
        return User.objects.create_user(**validated_data)



class BankAccountSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    account_age_days = serializers.SerializerMethodField()

    class Meta:
        model = BankAccount
        fields = [
            'id',
            'username',
            'balance',
            'created_at',
            'account_age_days'
        ]
        read_only_fields = ['balance', 'created_at']

    def get_account_age_days(self, obj):
        return (obj.created_at.date() - obj.created_at.date()).days



class TransactionSerializer(serializers.ModelSerializer):
    transaction_type_display = serializers.CharField(
        source='get_transaction_type_display',
        read_only=True
    )

    class Meta:
        model = Transaction
        fields = [
            'id',
            'transaction_type',
            'transaction_type_display',
            'amount',
            'description',
            'created_at'
        ]
        read_only_fields = ['id', 'transaction_type', 'created_at']



class DepositSerializer(serializers.Serializer):
    amount = serializers.DecimalField(
        max_digits=12,
        decimal_places=2,
        min_value=Decimal('0.01')
    )

    def validate_amount(self, value):
        if value > Decimal('1000000'):
            raise serializers.ValidationError("Deposit limit exceeded.")
        return value

class WithdrawSerializer(serializers.Serializer):
    amount = serializers.DecimalField(
        max_digits=12,
        decimal_places=2,
        min_value=Decimal('0.01')
    )


class TransferSerializer(serializers.Serializer):
    recipient_username = serializers.CharField(max_length=150)
    amount = serializers.DecimalField(
        max_digits=12,
        decimal_places=2,
        min_value=Decimal('0.01')
    )

    def validate_recipient_username(self, value):
        if not User.objects.filter(username=value).exists():
            raise serializers.ValidationError("Recipient does not exist.")
        return value

    def validate(self, data):
        request = self.context.get('request')
        if request and request.user.username == data['recipient_username']:
            raise serializers.ValidationError("You cannot transfer money to yourself.")
        return data
