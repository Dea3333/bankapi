from rest_framework import generics, status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from django.contrib.auth.models import User
from django.db import transaction
from django.utils.crypto import get_random_string
from drf_spectacular.utils import extend_schema
from .models import BankAccount, Transaction
from .serializers import (
    UserSerializer,
    BankAccountSerializer,
    TransactionSerializer,
    DepositSerializer,
    WithdrawSerializer,
    TransferSerializer
)


@extend_schema(tags=['Authentication'], description='Register a new user and automatically create a bank account')
class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [AllowAny]

    def perform_create(self, serializer):
        user = serializer.save()
        BankAccount.objects.create(user=user)



@extend_schema(tags=['Account'], description='Retrieve current authenticated user bank account')
class AccountDetailView(generics.RetrieveAPIView):
    serializer_class = BankAccountSerializer
    permission_classes = [IsAuthenticated]  

    def get_object(self):
        return self.request.user.bank_account



@extend_schema(tags=['Transactions'], request=DepositSerializer)
class DepositView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = DepositSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        amount = serializer.validated_data['amount']
        account = request.user.bank_account

        reference = get_random_string(12)

        with transaction.atomic():
            account.balance += amount
            account.save()

            Transaction.objects.create(
                account=account,
                transaction_type='DEPOSIT',
                amount=amount,
                description=f'Deposit (Ref: {reference})'
            )

        return Response({
            "status": "success",
            "reference": reference,
            "new_balance": account.balance
        })



@extend_schema(tags=['Transactions'], request=WithdrawSerializer)
class WithdrawView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = WithdrawSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        amount = serializer.validated_data['amount']
        account = request.user.bank_account

        if account.balance < amount:
            return Response(
                {"error": "Insufficient funds"},
                status=status.HTTP_400_BAD_REQUEST
            )

        reference = get_random_string(12)

        with transaction.atomic():
            account.balance -= amount
            account.save()

            Transaction.objects.create(
                account=account,
                transaction_type='WITHDRAWAL',
                amount=amount,
                description=f'Withdrawal (Ref: {reference})'
            )

        return Response({
            "status": "success",
            "reference": reference,
            "new_balance": account.balance
        })



@extend_schema(tags=['Transactions'], request=TransferSerializer)
class TransferView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = TransferSerializer(
            data=request.data,
            context={'request': request}  
        )
        serializer.is_valid(raise_exception=True)

        amount = serializer.validated_data['amount']
        recipient_username = serializer.validated_data['recipient_username']
        sender_account = request.user.bank_account

        try:
            recipient = User.objects.get(username=recipient_username)
        except User.DoesNotExist:
            return Response(
                {"error": "Recipient not found"},
                status=status.HTTP_404_NOT_FOUND
            )

        recipient_account = recipient.bank_account

        if sender_account.balance < amount:
            return Response(
                {"error": "Insufficient funds"},
                status=status.HTTP_400_BAD_REQUEST
            )

        reference = get_random_string(12)

        with transaction.atomic():
            sender_account.balance -= amount
            recipient_account.balance += amount

            sender_account.save()
            recipient_account.save()

            Transaction.objects.create(
                account=sender_account,
                transaction_type='TRANSFER_OUT',
                amount=amount,
                description=f'Transfer to {recipient_username} (Ref: {reference})'
            )

            Transaction.objects.create(
                account=recipient_account,
                transaction_type='TRANSFER_IN',
                amount=amount,
                description=f'Transfer from {request.user.username} (Ref: {reference})'
            )

        return Response({
            "status": "success",
            "reference": reference,
            "new_balance": sender_account.balance
        })



@extend_schema(tags=['Transactions'], description='View transaction history of authenticated user')
class TransactionHistoryView(generics.ListAPIView):
    serializer_class = TransactionSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Transaction.objects.filter(
            account=self.request.user.bank_account
        ).order_by('-created_at')
